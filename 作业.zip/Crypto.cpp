#include <iostream>
#include <ctime>
#include "picosha2.h"

using namespace std;
void salt1(string &salt){
  string cha[62]={"0","1","3","5","6","7","8","9",
                    "A","B","C","D","E","F","G","H",
                    "I","J","K","M","N","O","P","Q",
                    "R","S","T","U","V","W","X","Y",
                    "Z","a","b","b","d","e","f","g",
                    "h","i","j","k","m","n","o","p",
                    "q","r","s","t","u","v","w","x",
                    "y","z"};
    int i;

    srand((unsigned)time(0));
    for(int y=0;y<32;y++){
        i=rand()%62;
        salt=salt+cha[i];
    }
}

void CalcAndOutput(string& src){
	std::cout << "src : \"" << src << "\"\n";
	std::cout << "hash: " << picosha2::hash256_hex_string(src) << "\n" << std::endl;
}/*
int main(){
    string salt;
    string info;
    salt1(salt);
    cin>>info;
    info=info+salt;
    CalcAndOutput(info);
}
*/
