#include<iostream>
#include<String>
#include<fstream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Crypto.cpp"
#include <string.h>
using namespace std;


struct flay
{
    string no;
    string splace;
    string rplace;
    string stime;
    string rtime;
    string priva;
    string type;
    int sit;
    int sitted;
    string postnum[100];
};

int check(int d1, int s1, int m1,int d2, int s2, int m2){
            if(d1<d2){
                return 1;
            }else if(d1>d2){
                        return 0;
                    }else{
                        if(s1<s2){
                            return 1;
                        }else if(s1>s2){
                            return 0;
                            }else{
                                if(m1<m2){
                                    return 1;
                                        }else if(m1>m2){
                                            return 0;
                                                }else{
                                                    return 0;
            }
            }
            }
}


class flight{
    private:
        string no;
        string splace;
        string rplace;
        string stime;
        string rtime;
        string  priva;
        string type;
        int  sit;
        int  sitted;
        string postnum[100];
    public:
        flight(){

        }

        flight(string  No, string Splace, string Rplace, string Stime, string Rtime, string Priva, string Type, int Sit, int Sitted){
             no      = No;
             splace  = Splace;
             rplace  = Rplace;
             stime   = Stime;
             rtime   = Rtime;
             priva   = Priva;
             type    = Type;
             sit     = Sit;
             sitted  = Sitted;
            // postnum = new string[sit+1];
             for(int i=1;i<sit+1;i++){
                postnum[i]=="";
            }
         }
        void Show(){
            cout<<"the No."<<no<<endl;
            cout<<"from "<<splace<<" to "<<rplace<<endl;
            cout<<"fly: "<<stime<<endl;
            cout<<"get: "<<rtime<<endl;
            cout<<"the private is "<<priva<<endl;
            cout<<"the type is "<<type<<endl;
            cout<<"there sit is "<<sitted<<"/"<<sit<<endl;
        }

        string getnum(){
            return no;
        }

        void Get(string Post,int n){
            if(sitted == 0){
                cout<<"there is no sit. please choice other."<<endl;
            }else{
                sitted = sitted - 1;
                    if(postnum[n]==""){
                        postnum[n] = Post;
                    }
                    else
                    {
                        cout<<"this sit was orded";
                        exit(0);
                    }

                cout<<"success! Enjoy it."<<endl;

            }
        }
        void Getw(int n){
            //是否成功取消 1 or 0
                        postnum[n]=="";
                        sitted=sitted+1;
                        cout<<"success!"<<endl;
                        cout<<"there sit is "<<sitted<<"/"<<sit<<endl;
        }
        ~flight(){
           // delete[] postnum;
            //cout<<"the "<<no<<" was deleted"<<endl;
        }

};

class com{
    private:
        string name;
        string post;
        string nation;
        string phone;
        string  password;
        string salt;
    public:
        com(string n, string p, string n1, string ph, string pa, string sal){
            name = n;
            post = p;
            nation = n1;
            phone = ph;
            password = pa;
            salt = sal;
        }
        com(){

        }
        string  getpost(){
            return post;
        }
        void Show(){
            cout<<name<<" : "<<post<<" : "<<nation<<" : "<<phone<<" : "<<password<<endl;
        }
        int login(string ps){
        if(ps == password){
            return 1;
        }else {
            return 0;
        }
    }
};

void showallfly(){
    flay m;
    string sitt;
    string see;
    char name[100];
    string nam[100];
    int i=0;
    ifstream nf("1.txt");
    while(!nf.eof()){
        nf.getline(name,10,'\t');
        nam[i]=name;
        cout<<nam[i]<<" ";
        i++;
    }
    nf.close();
    char ss[100];
    for(int t=0;t<i;t++){
    ifstream fin(nam[t]);
        while(!fin.eof()){
        fin.getline(ss,10,'\t');m.no=ss;
        fin.getline(ss,10,'\t');m.splace=ss;
        fin.getline(ss,10,'\t');m.rplace=ss;
        fin.getline(ss,10,'\t');m.stime=ss;
        fin.getline(ss,10,'\t');m.rtime=ss;
        fin.getline(ss,10,'\t');m.priva=ss;
        fin.getline(ss,10,'\t');m.type=ss;
        fin.getline(ss,10,'\t');sitt = ss;
        fin.getline(ss,10,'\t');see = ss;
        for(int u=0;u<100;u++){
            fin.getline(ss,10,'\t');
            m.postnum[u]=ss;
        }
        if(see==""){
                break;
        }
        m.sit = std::stoi(sitt);
        m.sitted = std::stoi(see);
       // cout<<sitt<<endl;
        fin.close();
        flight q(m.no, m.splace, m.rplace, m.stime, m.rtime, m.priva, m.type, m.sit,m.sitted);
        q.Show();
        }
    }
}

void showone(string s, flay &m){
    string sitt;
    string sse;
    char name[100];
    string nam[100];
    int i = 0;
    ifstream nf("1.txt");
    while (!nf.eof())
    {
        nf.getline(name, 10, '\t');
        nam[i] = name;
        if(nam[i] == s){
            break;
        }
        i++;
    }
    nf.close();
    char ss[100];
    ifstream fin(nam[i]);
    if (!fin)
    {
        cout << "there is no that fly!" << endl;
    }
        fin.getline(ss, 10, '\t');
        m.no = ss;
        fin.getline(ss, 10, '\t');
        m.splace = ss;
        fin.getline(ss, 10, '\t');
        m.rplace = ss;
        fin.getline(ss, 10, '\t');
        m.stime = ss;
        fin.getline(ss, 10, '\t');
        m.rtime = ss;
        fin.getline(ss, 10, '\t');
        m.priva = ss;
        fin.getline(ss, 10, '\t');
        m.type = ss;
        fin.getline(ss, 10, '\t');
        sitt = ss;
        fin.getline(ss, 10, '\t');
        sse = ss;
        if(sitt!=""){
        m.sit = std::stoi(sitt);
        }
        if(sse!=""){
        m.sitted = std::stoi(sse);
        }
        for(int u=0;u<100;u++){
        fin.getline(ss,10,'\t');
            m.postnum[u]=ss;
           // cout<<m.postnum[u]<<endl;
        }
        fin.close();
        flight q(m.no, m.splace, m.rplace, m.stime, m.rtime, m.priva, m.type, m.sit, m.sitted);
        q.Show();
}


void file(flay &s){
    int day1, hour1, min1;
    int day2, hour2, min2;
    cout << "no: ";
    cin >> s.no;
    cout << "\nbegin: ";
    cin >> s.splace;
    cout << "\nend: ";
    cin >> s.rplace;
    cout << "\nstart time(day hour min): ";
    cin >> day1>>hour1>>min1;
    cout << "\nend time(day hour min): ";
    cin >> day2>>hour2>>min2;
    cout << "\npriva: ";
    cin >> s.priva;
    cout << "\ntype: ";
    cin >> s.type;
    cout << "\nsit :";
    cin >> s.sit;
    s.sitted = s.sit;
  while(!check(day1,hour1,min1,day2,hour2,min2)){
        cout<<"input time is error!"<<endl;
        cout<<"inout again!"<<endl;
        cout << "\nstart time(day hour min): ";
        cin >> day1>>hour1>>min1;
        cout << "\nend time(day hour min): ";
        cin >> day2>>hour2>>min2;
    }

    s.stime=to_string(day1)+"/"+to_string(hour1)+":"+to_string(min1);
    s.rtime=to_string(day2)+"/"+to_string(hour2)+":"+to_string(min2);
    ofstream nf("1.txt", ios::app);
    nf<<s.no<<'\t';
    nf.close();
    ofstream fout(s.no);
    if (!fout)
    {
        cout << "bad" << endl;
        exit(0);
    }
    fout << s.no << '\t' << s.splace << '\t' << s.rplace << '\t' << s.stime << '\t' << s.rtime << '\t' << s.priva << '\t' << s.type << '\t' << s.sit <<'\t'<<s.sitted<< '\t';
    for(int y;y<100;y++){
        fout<<s.postnum[y]<<'\t';
    }
    fout.close();
}

void deletef(string no){
    char name[100];
    string nam[100];
    int i=0;
    ifstream nf("1.txt");
    while(!nf.eof()){
        nf.getline(name,10,'\t');
        nam[i]=name;
        cout<<nam[i]<<" ";
        if(nam[i]==no){
            nam[i]="";
            cout<<"ok"<<endl;
        }
        i++;
    }
    nf.close();
    ofstream mf("1.txt");
    for(int r=0;r<i;r++){
        mf<<nam[r]<<'\t';
    }


}

void fileupdata(string n, flay &s){
    ofstream fout(n);
    if (!fout)
    {
        cout << "bad" << endl;
        exit(0);
    }
    fout << s.no << '\t' << s.splace << '\t' << s.rplace << '\t' << s.stime << '\t' << s.rtime << '\t' << s.priva << '\t' << s.type << '\t' << s.sit <<'\t'<<s.sitted<< '\t';

    for(int t=0; t<100;t++){
        fout<<s.postnum[t]<<'\t';
    }
    fout.close();
}

void registera(){
    com cc(" "," "," "," "," "," ");
    string n;
    string na;
    string po;
    string nat;
    string p;
    string pa;
    string salt;
    cout<<"input the info:"<<endl;
    cout<<"name: ";
    cin>>na;
    cout<<"postid: ";
    cin>>po;
    cout<<"nation: ";
    cin>>nat;
    cout<<"phone :";
    cin>>p;
    cout<<"password: ";
    cin>>pa;
    salt1(salt);
    pa=pa+salt;
    pa=picosha2::hash256_hex_string(pa);
    cc = com(na, po, nat, p, pa, salt);
    ofstream cou(na);
    if (!cou)
    {
        cout << "bad" << endl;
        exit(0);
    }
    cou<<na<<'\t'<<po<<'\t'<<nat<<'\t'<<p<<'\t'<<pa<<'\t'<<salt;
    cou.close();
    cout<<"regest success!"<<endl;
}

void login(com &ct){
    string n;
    string na;
    string po;
    string nat;
    string p;
    string pa;
    string salt;
    cout<<"input your name: ";
    cin>>na;
    ifstream cs(na);
    if(!cs){
        cout<<"no re"<<endl;
        exit(0);
    }
    cs>>na>>po>>nat>>p>>pa>>salt;
    cs.close();
    ct = com(na,po,nat,p,pa,salt);
        //ct.Show();
        cout<<"input your password: ";
        cin>>pa;
        pa=pa+salt;
        pa=picosha2::hash256_hex_string(pa);
        if(ct.login(pa)){
            cout<<"login on "<<na<<endl;
        }else{
            cout<<"login fail!"<<endl;
            exit(0);
        }
}

int main(){
    int t;
    int sii;
    int flag=1;
    int id;
    string sr;
    flight q("1","1","1","1","1","1","1",2,1);
    com cc(" "," "," "," "," "," ");
    com ct(" "," "," "," "," "," ");
    flay s;
    flay m;
    string n;
    string na;
    string po;
    string nat;
    string p;
    string pa;
    cout<<"input your id: 1.com 2.admin 3.new com 4. new admin"<<endl;
    cin>>id;
    if(id==3){
        registera();
        login(ct);
    }else if(id == 1){
       login(ct);
    }
    if(id==2){
        login(ct);
        while(flag!=0){
        cout<<"1. show all fly;"<<endl;
        cout<<"2. get a fly;"<<endl;
        cout<<"3. return a fly"<<endl;
        cout<<"4. show one fly"<<endl;
        cout<<"5. add a fly"<<endl;
        cout<<"6. delete a fly"<<endl;
        cout<<"7. show your info"<<endl;
        cout<<"0.exit"<<endl;
        cin>>flag;

        switch (flag)
        {
            case 1:
                showallfly();
                break;
            case 4:
                cout<<"inupt the number of the fly:";
                cin>>n;
                showone(n,m);
                break;
            case 2:
                cout<<"which fly would you like?";
                cin>>n;
                cout<<"which sit do you want!";
                cin>>sii;
                showone(n,m);
                q = flight(m.no, m.splace, m.rplace, m.stime, m.rtime, m.priva, m.type, m.sit,m.sitted);
                sr = ct.getpost();

                cout<<sr;

               for(int y=0; y<100;y++){
                    if(m.postnum[y]==""){
                        m.postnum[y]=sr;
                        break;
                    }
                }
                if(m.sitted>0){
                    m.sitted--;
                }else{
                    cout<<"there is no sit"<<endl;
                    break;
                }
                q.Get(sr,sii);
                fileupdata(n,m);
                q.Show();
                break;
            case 3:
                cout<<"input the fly:";
                cin>>n;
                cout<<"input the sit:";
                cin>>sii;
                showone(n,m);
                q = flight(m.no, m.splace, m.rplace, m.stime, m.rtime, m.priva, m.type, m.sit,m.sitted);
                q.Show();
                q.Getw(sii);
                sr = ct.getpost();
                for(int y=0; y<100;y++){
                    if(m.postnum[y]==sr){
                        m.postnum[y]="";
                        break;
                    }
                }
                m.sitted++;
                fileupdata(n,m);
                break;
            case 5:
                cout<<"input the number of the flight: ";
                cin>>t;
                for(int y = 0; y<t; y++){
                    cout<<"input the info of the fight:"<<endl;
                    file(s);
                    q=flight(s.no, s.splace, s.rplace, s.stime, s.rtime, s.priva, s.type, s.sit,s.sitted);
                    cout<<"add successfully!\n"<<endl;
                    cout<<"the infomation of the the fly:"<<endl;
                    q.Show();
                }
                break;
            case 6:
            cout<<"input the no of the fly"<<endl;
            cin>>n;
            deletef(n);
            case 7:
                ct.Show();
                break;
            default:
                break;
        }
        }
        }if(id == 4){
        registera();
        login(ct);
        while(flag!=0){
        cout<<"1. show all fly;"<<endl;
        cout<<"2. get a fly;"<<endl;
        cout<<"3. return a fly"<<endl;
        cout<<"4. show one fly"<<endl;
        cout<<"5. add a fly"<<endl;
        cout<<"6. delete a fly"<<endl;
        cout<<"7. show your info"<<endl;
        cout<<"0.exit"<<endl;
        cin>>flag;

        switch (flag)
        {
            case 1:
                showallfly();
                break;
            case 4:
                cout<<"inupt the number of the fly:";
                cin>>n;
                showone(n,m);
                break;
            case 2:
                cout<<"which fly would you like?";
                cin>>n;
                cout<<"which sit do you want!";
                cin>>sii;
                showone(n,m);
                q = flight(m.no, m.splace, m.rplace, m.stime, m.rtime, m.priva, m.type, m.sit,m.sitted);
                sr = ct.getpost();

                cout<<sr;

               for(int y=0; y<100;y++){
                    if(m.postnum[y]==""){
                        m.postnum[y]=sr;
                        break;
                    }
                }
                if(m.sitted>0){
                    m.sitted--;
                }else{
                    cout<<"there is no sit"<<endl;
                    break;
                }
                q.Get(sr,sii);
                fileupdata(n,m);
                q.Show();
                break;
            case 3:
                cout<<"input the fly:";
                cin>>n;
                cout<<"input the sit:";
                cin>>sii;
                showone(n,m);
                q = flight(m.no, m.splace, m.rplace, m.stime, m.rtime, m.priva, m.type, m.sit,m.sitted);
                q.Show();
                q.Getw(sii);
                sr = ct.getpost();
                for(int y=0; y<100;y++){
                    if(m.postnum[y]==sr){
                        m.postnum[y]="";
                        break;
                    }
                }
                m.sitted++;
                fileupdata(n,m);
                break;
            case 5:
                cout<<"input the number of the flight: ";
                cin>>t;
                for(int y = 0; y<t; y++){
                    cout<<"input the info of the fight:"<<endl;
                    file(s);
                    q=flight(s.no, s.splace, s.rplace, s.stime, s.rtime, s.priva, s.type, s.sit,s.sitted);
                    cout<<"add successfully!\n"<<endl;
                    cout<<"the infomation of the the fly:"<<endl;
                    q.Show();
                }
                break;
            case 6:
            cout<<"input the no of the fly"<<endl;
            cin>>n;
            deletef(n);
            case 7:
                ct.Show();
                break;
            default:
                break;
        }
        }
        }else {
        while(flag!=0){
        cout<<"1. show all fly;"<<endl;
        cout<<"2. get a fly;"<<endl;
        cout<<"3. return a fly"<<endl;
        cout<<"4. show one fly"<<endl;
        cout<<"5. show your info"<<endl;
        cout<<"0.exit"<<endl;
        cin>>flag;

        switch (flag)
        {
            case 1:
                showallfly();
                break;
            case 4:
                cout<<"inupt the number of the fly:";
                cin>>n;
                showone(n,m);
                break;
            case 2:
                cout<<"which fly would you like?";
                cin>>n;
                cout<<"which sit do you want!";
                cin>>sii;
                showone(n,m);
                q = flight(m.no, m.splace, m.rplace, m.stime, m.rtime, m.priva, m.type, m.sit,m.sitted);
                sr = ct.getpost();

                cout<<sr;

               for(int y=0; y<100;y++){
                    if(m.postnum[y]==""){
                        m.postnum[y]=sr;
                        break;
                    }
                }
                if(m.sitted>0){
                    m.sitted--;
                }else{
                    cout<<"there is no sit"<<endl;
                    break;
                }
                q.Get(sr,sii);
                fileupdata(n,m);
                q.Show();
                break;
            case 3:
                cout<<"input the fly:";
                cin>>n;
                cout<<"input the sit:";
                cin>>sii;
                showone(n,m);
                q = flight(m.no, m.splace, m.rplace, m.stime, m.rtime, m.priva, m.type, m.sit,m.sitted);
                q.Show();
                q.Getw(sii);
                sr = ct.getpost();
                for(int y=0; y<100;y++){
                    if(m.postnum[y]==sr){
                        m.postnum[y]="";
                        break;
                    }
                }
                m.sitted++;
                fileupdata(n,m);
                break;
            case 5:
                ct.Show();
                break;
            default:
                break;
        }
        }
        }
        return 0;
}
